#include "version.h"
const char *janus_build_git_sha = "4ff8a78f41b329f5efdf99116edb97ff609ee858";
const char *janus_build_git_time = "2020年 07月 31日 星期五 16:12:57 CST";
int janus_version = 103;
const char *janus_version_string = "0.10.3";
const char *libnice_version_string = "0.1.16";
